var janela = document.getElementById("janela");


function abrirJanela(){
	janela.src = "img/1.png";
}

function fecharJanela(){
	janela.src = "img/2.png";
}

function quebrarJanela(){
	janela.src = "img/3.png";
}